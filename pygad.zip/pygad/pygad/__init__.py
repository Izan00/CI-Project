from .pygad import * # Relative import.

__version__ = "2.18.1"
